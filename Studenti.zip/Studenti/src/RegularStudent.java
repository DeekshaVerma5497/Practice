import javax.persistence.Entity;

@Entity
public class RegularStudent extends Student{

	private String rSalary;

	public String getrSalary() {
		return rSalary;
	}

	public void setrSalary(String rSalary) {
		this.rSalary = rSalary;
	}
	
	
}
