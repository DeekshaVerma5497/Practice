import javax.persistence.Entity;

@Entity
public class ParttimeStudent extends Student{
	
	private String pSalary;

	public String getpSalary() {
		return pSalary;
	}

	public void setpSalary(String pSalary) {
		this.pSalary = pSalary;
	}
	
	

}
