package com.usertracker.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.usertracker.model.User;
import com.usertracker.service.MyService;
import com.usertracker.service.SecurityTokenGenerator;


@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

	@Autowired(required=true)
	private MyService myservice;
	
	@Autowired
	private SecurityTokenGenerator tokenGenerator;

	
	@PostMapping("/user/registerUser")
	public ResponseEntity<?> registerUser(@RequestBody User user) {
		try {
			boolean val=myservice.createUser(user);
			return new ResponseEntity<Boolean>(val, HttpStatus.CREATED);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			return new ResponseEntity<String>("Already Exists", HttpStatus.CONFLICT);
		}
	}

	
	@PostMapping("user/loginUser")
	@CrossOrigin(origins = "http://localhost:4200")
	public ResponseEntity<?> login(@RequestBody User loginDetail){
		try {
			if (null == loginDetail.getUserName() || null == loginDetail.getPassword()) {
				throw new Exception("User Id or Password canot be empty.");
			}
			User user = myservice.findByUserIdAndPassword(loginDetail.getUserName(), loginDetail.getPassword());
			Map<String, String> map = tokenGenerator.generateToken(user);
			return new ResponseEntity<Map<String, String>>(map, HttpStatus.OK);

		} catch (Exception e) {
			return new ResponseEntity<String>("{ \" message\": \"" + e.getMessage() + "\"}", HttpStatus.UNAUTHORIZED);
		}
	}
	

	
}
