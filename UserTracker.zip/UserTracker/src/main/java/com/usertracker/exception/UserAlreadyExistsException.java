package com.usertracker.exception;

public class UserAlreadyExistsException extends Exception{

	private static final long serialVersionUID = -2547317032607976157L;

	public UserAlreadyExistsException(String message) {
		super(message);
	}

}
