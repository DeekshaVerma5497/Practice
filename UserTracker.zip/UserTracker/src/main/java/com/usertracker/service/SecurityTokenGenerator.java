package com.usertracker.service;

import java.util.Map;

import com.usertracker.model.User;

public interface SecurityTokenGenerator {
	Map<String, String> generateToken(User user);
}
