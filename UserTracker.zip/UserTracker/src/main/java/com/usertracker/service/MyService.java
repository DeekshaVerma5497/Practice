package com.usertracker.service;

import com.usertracker.exception.UserAlreadyExistsException;
import com.usertracker.model.User;

public interface MyService {

	User findByUserIdAndPassword(String userName, String password);

	boolean createUser(User user) throws UserAlreadyExistsException;

	

}
