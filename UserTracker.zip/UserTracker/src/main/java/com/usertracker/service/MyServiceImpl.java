package com.usertracker.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.usertracker.exception.UserAlreadyExistsException;
import com.usertracker.model.User;
import com.usertracker.repository.UserRepository;

@Service("myservice")
public class MyServiceImpl implements MyService{

	@Autowired
	UserRepository urepo;
	public MyServiceImpl(UserRepository urepo) {
		super();
		this.urepo = urepo;
	}



	public boolean createUser(User user) throws UserAlreadyExistsException {
		List<User> users=new ArrayList<>();
		urepo.findAll().forEach(users::add);
		for(User u:users) {
			if(user.getEmail().equals(u.getEmail())||user.getUserName().equals(u.getuId())) {
				throw new UserAlreadyExistsException("User with id already exists");
			}
		}
		
		urepo.save(user);
		return true;
		
	}

	public User findByUserIdAndPassword(String userName, String password) {
		List<User> users=new ArrayList<>();
		User user = null;
		urepo.findAll().forEach(users::add);
		for(User u:users) {
			if(u.getUserName().equals(userName) && u.getPassword().equals(password)) {
				user=u;
			}
		}
		return user;
	}

	

	
}
